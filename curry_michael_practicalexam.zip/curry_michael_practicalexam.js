//Michael Curry
//November 21, 2013
//Scalable Data Inf. SDI 1311
//Practical Exam
//Problem 1



var userNum = prompt("What is your phone number?","XXX-XXX-XXXX");


var funcNumber = function(userNum){

    checkDash = userNum.indexOf("-");
    checkLastDash = userNum.lastIndexOf("-")
    numb1 = userNum.substr(0,3);
    numb2 = userNum.substr(4,3);
    numb3 = userNum.substr(8,4);
    
    num1 = isNaN(numb1);
    num2 = isNaN(numb2);
    num3 = isNaN(numb3);
    
    
    
    
    if (checkDash === 3 && checkLastDash === 7) {
        
        if (num1 === false && num2 === false && num3 === false) {
            
            return "This is a number and is formatted correctly";
        
        }else{
            
            return "Formatted correctly but this isnt a phone number";
        }
        
    
}else{
    
     return "The phone number formatt is invalid/ Or isnt a phone number";
    
    
};
};

var myPhone= funcNumber(userNum);
console.log(myPhone);
